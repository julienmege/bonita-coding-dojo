var module;
try {
  module = angular.module('bonitasoft.ui.fragments');
} catch (e) {
  module = angular.module('bonitasoft.ui.fragments', []);
  angular.module('bonitasoft.ui').requires.push('bonitasoft.ui.fragments');
}
module.directive('pbFragmentVacationRequestReview', function() {
  return {
    template: '<div>    <div class="row">\n        <div pb-property-values=\'1c85bb1d-8317-4e62-b913-7f29cd982f39\'>\n    <div ng-if="!properties.hidden" class="component col-lg-3  col-md-4  col-sm-12  col-xs-12" ng-class="properties.cssClasses">\n        <pb-checkbox></pb-checkbox>\n    </div>\n</div><div pb-property-values=\'8710bf61-0800-4477-b083-512e42ea494c\'>\n    <div ng-if="!properties.hidden" class="component col-lg-3  col-md-4  col-sm-12  col-xs-12" ng-class="properties.cssClasses">\n        <pb-input></pb-input>\n    </div>\n</div><div pb-property-values=\'e75370f3-dc0f-42ef-93b3-fc567f36c2b6\'>\n    <div ng-if="!properties.hidden" class="component col-lg-3  col-md-2  col-sm-12  col-xs-12" ng-class="properties.cssClasses">\n        <pb-button></pb-button>\n    </div>\n</div><div pb-property-values=\'27ab26d9-cb88-4f4c-b694-8ab233647d13\'>\n    <div ng-if="!properties.hidden" class="component col-lg-3  col-md-2  col-sm-12  col-xs-12" ng-class="properties.cssClasses">\n        <pb-button></pb-button>\n    </div>\n</div>\n    </div>\n</div>'
  };
});
