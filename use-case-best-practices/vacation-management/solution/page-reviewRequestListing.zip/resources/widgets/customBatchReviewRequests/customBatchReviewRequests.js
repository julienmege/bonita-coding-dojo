angular.module('bonitasoft.ui.widgets')
  .directive('customBatchReviewRequests', function() {
    return {
      controllerAs: 'ctrl',
      controller: function BatchReviewRequestController($scope, $http) {
    var vm = this;

    vm.toggleSelection = function (value) {
        $scope.properties.requests.forEach(function (request) {
            request.$selected = value;
        });
    };

    vm.acceptRequests = function () {
        vm.listSelectedTasks().forEach(executeTask.bind(null, 'approved'));
    };

    vm.refuseRequests = function () {
        vm.listSelectedTasks().forEach(executeTask.bind(null, 'refused'));
    };

    vm.listSelectedTasks = function() {
        return $scope.properties.requests && $scope.properties.requests
            .filter(function isSelected(request) {
                return request.$selected;
            });
    };

    function executeTask(status, request) {
        $http.post('../API/bpm/userTask/' + request.task.id + '/execution', {
            status: status,
            comments: request.vacationRequest.comments || ''
        });
    }
}
,
      template: '<div class="toolbar">\n    <input type="checkbox" ng-change="ctrl.toggleSelection(value)" ng-model="value"></input>\n    <button ng-click="ctrl.acceptRequests()" ng-disabled="!ctrl.listSelectedTasks().length">Accept</button>\n    <button ng-click="ctrl.refuseRequests()" ng-disabled="!ctrl.listSelectedTasks().length">Refuse</button>\n</div>\n'
    };
  });
